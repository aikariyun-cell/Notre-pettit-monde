-- ================================================================
-- 📍 Nuestra Distancia — migración de base de datos
-- ================================================================
-- Cópienlo y péguenlo en el SQL Editor de su proyecto de Supabase
-- (Project > SQL Editor > New query) y ejecútenlo una sola vez.
-- No modifica ninguna tabla existente, incluida mapa_lugares.
--
-- Igual que en supabase/mapa_recuerdos.sql, las políticas de abajo
-- asumen una tabla `couple_members(couple_id, user_id)`. Ajusten esa
-- subconsulta si en su proyecto vive distinto.
-- ================================================================

-- ---------- distancia_compartida ----------
-- Una fila por persona (no por pareja). Nunca se guarda un historial:
-- cada activación reemplaza (upsert) la fila anterior de esa persona.
-- lat/lng se guardan redondeados a ~1 km de precisión (ver
-- redondearAproximado en js/nuestra-distancia.js) — nunca la ubicación
-- exacta, y nunca junto con un registro de movimientos.
create table if not exists public.distancia_compartida (
  couple_id uuid not null references public.couples(id) on delete cascade,
  user_id uuid not null,
  activo boolean not null default false,
  pausado boolean not null default false,
  duracion text not null default 'manual',   -- '1h' | '8h' | 'hoy' | 'manual'
  expira_at timestamptz,                     -- null = solo se apaga a mano
  lat double precision,                      -- aproximada (redondeada), nunca exacta
  lng double precision,                      -- aproximada (redondeada), nunca exacta
  ciudad text,
  estado text,
  pais text,
  ocultar_para_mi boolean not null default false,
  updated_at timestamptz not null default now(),
  primary key (couple_id, user_id)
);
create index if not exists distancia_compartida_couple_idx on public.distancia_compartida(couple_id);

alter table public.distancia_compartida enable row level security;

create policy "distancia_compartida: solo la propia pareja" on public.distancia_compartida
  for all using (
    couple_id in (select couple_id from public.couple_members where user_id = auth.uid())
  ) with check (
    couple_id in (select couple_id from public.couple_members where user_id = auth.uid())
  );

-- ================================================================
-- Nada más se crea: no hay tabla de historial, no hay geocercas y no
-- hay ningún cron/trigger que lea el GPS por su cuenta. El vencimiento
-- de `expira_at` se revisa desde el cliente (js/nuestra-distancia.js)
-- cada vez que se abre la sección o desde una única lectura manual.
-- ================================================================

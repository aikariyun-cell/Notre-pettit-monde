# Notre petit monde — versión Next.js

Esta es la migración a **Next.js 14** (Pages Router) de la app original
`notre-petit-monde` (HTML + CSS + JS vanilla). El objetivo de esta migración
fue mantener el sitio **visualmente y funcionalmente idéntico** al original:

- El mismo `css/styles.css`, servido tal cual desde `/public/css/styles.css`.
- Los mismos 37 archivos `js/*.js`, servidos tal cual desde `/public/js/`,
  cargados **en el mismo orden exacto** que en el `index.html` original.
- El mismo `<head>` (metadatos, iconos en base64, Google Fonts).
- El mismo endpoint serverless `/api/livekit-token` (ahora como API Route de
  Next.js en `pages/api/livekit-token.js`), sin cambios en su lógica.
- El mismo `firebase-messaging-sw.js` en la raíz pública.

## Qué cambió (sólo estructura, no comportamiento)

- El HTML estático (`index.html`) se convirtió en:
  - `pages/_document.js`: `<head>` + carga de scripts (usa `next/script`
    con `strategy="beforeInteractive"` para preservar el orden de carga
    síncrono original).
  - `pages/index.js`: el markup del `<body>` (los mismos `id`/`class` que
    usa el JS original para manipular el DOM).
- Los iconos base64 del `<head>` se extrayeron a `lib/icons.js` (mismo
  contenido, sólo movidos a un archivo separado para mantener limpio el
  documento).
- El script inline de configuración de Firebase se movió a
  `public/js/firebase-config-inline.js` (mismo código, cargado como script
  externo en vez de inline).

Ningún archivo `.js` de `public/js/` fue modificado: siguen operando sobre
el DOM (`document.getElementById`, `switchTab()`, etc.) exactamente igual
que antes.

## Cómo correrlo

```bash
npm install
npm run dev     # http://localhost:3000
```

Para producción:

```bash
npm run build
npm run start
```

## Variables de entorno

El endpoint `pages/api/livekit-token.js` necesita, igual que en Vercel:

```
LIVEKIT_URL=wss://...
LIVEKIT_API_KEY=...
LIVEKIT_API_SECRET=...
```

Colócalas en un archivo `.env.local` (no incluido) o en el panel de tu
proveedor de hosting.

## Despliegue

Al ser un proyecto Next.js estándar, se puede desplegar directamente en
Vercel (`vercel deploy`) o cualquier hosting compatible con Next.js.

-- ================================================================
-- 📍 Mapa de Recuerdos — migración de base de datos
-- ================================================================
-- Este archivo NO se ejecuta solo: cópienlo y péguenlo en el SQL
-- Editor de su proyecto de Supabase (Project > SQL Editor > New query)
-- y ejecútenlo una sola vez. No modifica ninguna tabla existente.
--
-- Las políticas de RLS de abajo asumen que ya existe una tabla
-- `couple_members` con columnas (couple_id, user_id) — el mismo patrón
-- que usa el resto de la app para saber "a qué pareja pertenece este
-- usuario". Si en su proyecto esa comprobación vive en otra tabla o
-- función, ajusten sólo la subconsulta `select couple_id from
-- couple_members where user_id = auth.uid()` que se repite abajo.
-- ================================================================

-- ---------- mapa_lugares ----------
-- Guarda tanto los recuerdos ya visitados (visitado = true) como los
-- lugares pendientes por visitar (visitado = false). Nunca contiene una
-- traza de movimientos: cada fila es un lugar guardado a mano.
create table if not exists public.mapa_lugares (
  id uuid primary key default gen_random_uuid(),
  couple_id uuid not null references public.couples(id) on delete cascade,
  autor_id uuid not null,
  nombre text not null,
  categoria text not null default 'Favoritos',
  fecha date,
  descripcion text,
  notas text,
  emojis text,
  color text default '#eeb1cd',
  etiquetas text[] not null default '{}',
  fotos text[] not null default '{}',
  videos text[] not null default '{}',
  cartas_ids uuid[] not null default '{}',
  dibujos_ids uuid[] not null default '{}',
  scrapbook_pagina text,
  lat double precision,
  lng double precision,
  ciudad text,
  pais text,
  visitado boolean not null default true,
  prioridad text,            -- solo se usa cuando visitado = false ('alta'|'media'|'baja')
  fecha_planeada date,       -- solo se usa cuando visitado = false
  favorito boolean not null default false,
  eliminado boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists mapa_lugares_couple_idx on public.mapa_lugares(couple_id);

-- ---------- mapa_categorias ----------
-- Categorías personalizadas que la pareja crea además de las 12 predeterminadas.
create table if not exists public.mapa_categorias (
  id uuid primary key default gen_random_uuid(),
  couple_id uuid not null references public.couples(id) on delete cascade,
  nombre text not null,
  icono text not null default '📍',
  created_at timestamptz not null default now()
);
create index if not exists mapa_categorias_couple_idx on public.mapa_categorias(couple_id);

-- ---------- mapa_rutas ----------
create table if not exists public.mapa_rutas (
  id uuid primary key default gen_random_uuid(),
  couple_id uuid not null references public.couples(id) on delete cascade,
  autor_id uuid not null,
  nombre text not null,
  descripcion text,
  created_at timestamptz not null default now()
);
create index if not exists mapa_rutas_couple_idx on public.mapa_rutas(couple_id);

-- ---------- mapa_rutas_paradas ----------
create table if not exists public.mapa_rutas_paradas (
  id uuid primary key default gen_random_uuid(),
  ruta_id uuid not null references public.mapa_rutas(id) on delete cascade,
  orden int not null default 0,
  nombre text not null,
  icono text default '📍',
  notas text,
  fotos text[] not null default '{}',
  videos text[] not null default '{}',
  cartas_ids uuid[] not null default '{}',
  dibujos_ids uuid[] not null default '{}',
  created_at timestamptz not null default now()
);
create index if not exists mapa_rutas_paradas_ruta_idx on public.mapa_rutas_paradas(ruta_id);

-- ================================================================
-- Row Level Security: cada pareja solo ve y edita sus propios datos
-- ================================================================
alter table public.mapa_lugares enable row level security;
alter table public.mapa_categorias enable row level security;
alter table public.mapa_rutas enable row level security;
alter table public.mapa_rutas_paradas enable row level security;

create policy "mapa_lugares: solo la propia pareja" on public.mapa_lugares
  for all using (
    couple_id in (select couple_id from public.couple_members where user_id = auth.uid())
  ) with check (
    couple_id in (select couple_id from public.couple_members where user_id = auth.uid())
  );

create policy "mapa_categorias: solo la propia pareja" on public.mapa_categorias
  for all using (
    couple_id in (select couple_id from public.couple_members where user_id = auth.uid())
  ) with check (
    couple_id in (select couple_id from public.couple_members where user_id = auth.uid())
  );

create policy "mapa_rutas: solo la propia pareja" on public.mapa_rutas
  for all using (
    couple_id in (select couple_id from public.couple_members where user_id = auth.uid())
  ) with check (
    couple_id in (select couple_id from public.couple_members where user_id = auth.uid())
  );

create policy "mapa_rutas_paradas: solo la propia pareja" on public.mapa_rutas_paradas
  for all using (
    ruta_id in (
      select r.id from public.mapa_rutas r
      where r.couple_id in (select couple_id from public.couple_members where user_id = auth.uid())
    )
  ) with check (
    ruta_id in (
      select r.id from public.mapa_rutas r
      where r.couple_id in (select couple_id from public.couple_members where user_id = auth.uid())
    )
  );

-- ================================================================
-- Almacenamiento: las fotos y videos se guardan en el bucket 'media'
-- que la app ya usa para el álbum, dentro de las carpetas
-- {couple_id}/mapa/, {couple_id}/mapa-pendientes/ y {couple_id}/mapa-rutas/.
-- No hace falta crear un bucket nuevo ni tocar sus políticas de storage
-- si el bucket 'media' ya funciona para el Álbum.
-- ================================================================

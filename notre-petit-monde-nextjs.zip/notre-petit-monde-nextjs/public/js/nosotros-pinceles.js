/* ================= PINCELES EN NOSOTROS (lienzo colaborativo) ================= */
const PINCELES_TIPOS = [
  {id:'fino', label:'Fino', grosor:2, alpha:1, cap:'round'},
  {id:'grueso', label:'Grueso', grosor:7, alpha:1, cap:'round'},
  {id:'marcador', label:'Marcador', grosor:14, alpha:1, cap:'square'},
  {id:'resaltador', label:'Resaltador', grosor:16, alpha:0.35, cap:'square'},
  {id:'lapiz', label:'Lápiz', grosor:1.5, alpha:0.8, cap:'round'},
];
const PINCELES_COLORES = ['#3a2530','#c3527a','#e0a45f','#8a5ad0','#6fb0a3','#e06f8b','#2c2a4a','#ffffff'];
let pincelActivo = PINCELES_TIPOS[0];
let pincelColor = '#3a2530';
let pincelCtx = null, pincelDibujando = false, pincelHistorial = [];

(function envolverRenderNosotrosConPinceles(){
  let intentos = 0;
  const t = setInterval(()=>{
    intentos++;
    if(typeof window.renderNosotros==='function'){
      clearInterval(t);
      const original = window.renderNosotros;
      window.renderNosotros = async function(){
        await original();
        agregarSeccionPinceles();
      };
    } else if(intentos>150){ clearInterval(t); }
  }, 800);
})();

function agregarSeccionPinceles(){
  const main = document.getElementById('main');
  if(!main || document.getElementById('pincelesCard')) return;
  main.insertAdjacentHTML('beforeend', `
    <div class="card" id="pincelesCard">
      <h3>🖌️ Pinceles</h3>
      <p class="small muted">Dibujen algo juntos, aunque sea una tontería. Se guarda en su Álbum.</p>
      <canvas id="pincelCanvas" width="320" height="220" style="width:100%;background:#fff;border-radius:14px;touch-action:none;border:1px solid var(--linea)"></canvas>
      <div class="cat-chip-row" style="margin-top:8px;overflow-x:auto">
        ${PINCELES_TIPOS.map(p=>`<button class="cat-chip ${pincelActivo.id===p.id?'active':''}" onclick="elegirPincel('${p.id}')">🖌️ ${p.label}</button>`).join('')}
      </div>
      <div class="row" style="gap:6px;margin-top:8px;flex-wrap:wrap;align-items:center">
        ${PINCELES_COLORES.map(c=>`<div onclick="pincelColor='${c}'" style="width:26px;height:26px;border-radius:50%;background:${c};cursor:pointer;border:2px solid ${pincelColor===c?'#333':'rgba(0,0,0,.15)'}"></div>`).join('')}
        <input type="color" value="${pincelColor}" onchange="pincelColor=this.value" style="width:30px;height:26px;border:none;background:none;cursor:pointer">
        <button class="btn btn-sm" onclick="usarGoma()">🧹 Goma</button>
      </div>
      <div class="row" style="gap:8px;margin-top:8px">
        <button class="btn btn-sm" onclick="deshacerPincel()">↩️ Deshacer</button>
        <button class="btn btn-sm" onclick="limpiarPincel()">🗑️ Borrar todo</button>
        <button class="btn btn-sm btn-gold" onclick="guardarDibujoPincel()">💾 Guardar en álbum</button>
      </div>
    </div>`);
  inicializarCanvasPincel();
}
function elegirPincel(id){
  pincelActivo = PINCELES_TIPOS.find(p=>p.id===id) || PINCELES_TIPOS[0];
  document.querySelectorAll('#pincelesCard .cat-chip').forEach(b=>b.classList.remove('active'));
  const idx = PINCELES_TIPOS.findIndex(p=>p.id===id);
  const btns = document.querySelectorAll('#pincelesCard .cat-chip');
  if(btns[idx]) btns[idx].classList.add('active');
}
function usarGoma(){ pincelColor = '#ffffff'; }
function inicializarCanvasPincel(){
  const cv = document.getElementById('pincelCanvas');
  if(!cv || cv.dataset.listo) return;
  cv.dataset.listo = '1';
  pincelCtx = cv.getContext('2d');
  pincelCtx.fillStyle = '#ffffff'; pincelCtx.fillRect(0,0,cv.width,cv.height);
  guardarEstadoPincel();
  const pos = (e)=>{ const r=cv.getBoundingClientRect(); const p = e.touches?e.touches[0]:e; return [(p.clientX-r.left)*(cv.width/r.width), (p.clientY-r.top)*(cv.height/r.height)]; };
  const start = (e)=>{
    pincelDibujando = true;
    pincelCtx.globalAlpha = pincelActivo.alpha;
    pincelCtx.lineWidth = pincelActivo.grosor;
    pincelCtx.lineCap = pincelActivo.cap;
    pincelCtx.strokeStyle = pincelColor;
    const [x,y]=pos(e); pincelCtx.beginPath(); pincelCtx.moveTo(x,y);
  };
  const move = (e)=>{ if(!pincelDibujando) return; e.preventDefault(); const [x,y]=pos(e); pincelCtx.lineTo(x,y); pincelCtx.stroke(); };
  const end = ()=>{ if(pincelDibujando){ pincelDibujando=false; guardarEstadoPincel(); } };
  cv.addEventListener('mousedown', start); cv.addEventListener('mousemove', move); window.addEventListener('mouseup', end);
  cv.addEventListener('touchstart', start, {passive:false}); cv.addEventListener('touchmove', move, {passive:false}); cv.addEventListener('touchend', end);
}
function guardarEstadoPincel(){
  const cv = document.getElementById('pincelCanvas');
  if(!cv || !pincelCtx) return;
  pincelHistorial.push(cv.toDataURL());
  if(pincelHistorial.length>20) pincelHistorial.shift();
}
function deshacerPincel(){
  const cv = document.getElementById('pincelCanvas');
  if(!cv || pincelHistorial.length<2) return;
  pincelHistorial.pop();
  const anterior = pincelHistorial[pincelHistorial.length-1];
  const img = new Image();
  img.onload = ()=>{ pincelCtx.clearRect(0,0,cv.width,cv.height); pincelCtx.drawImage(img,0,0); };
  img.src = anterior;
}
function limpiarPincel(){
  const cv = document.getElementById('pincelCanvas');
  if(!cv || !pincelCtx) return;
  pincelCtx.fillStyle = '#ffffff'; pincelCtx.fillRect(0,0,cv.width,cv.height);
  guardarEstadoPincel();
}
async function guardarDibujoPincel(){
  const cv = document.getElementById('pincelCanvas');
  if(!cv) return;
  const img_url = await subirImagen(cv.toDataURL('image/png'), 'album', 'dibujo');
  await sb.from('album').insert({couple_id:SESSION.coupleId, autor_id:SESSION.user.id, tipo:'dibujo', img_url, texto:'Dibujado juntos en Nosotros 🖌️'});
  toast('Dibujo guardado en el álbum 🎨');
}
